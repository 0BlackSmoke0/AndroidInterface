package bandtec.com.testemenu

class Model(val title: String, val description: String, val img: Int) {


}